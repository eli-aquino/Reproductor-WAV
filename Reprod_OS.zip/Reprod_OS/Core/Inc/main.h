/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f1xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

void HAL_TIM_MspPostInit(TIM_HandleTypeDef *htim);

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define TaskInt_Pin GPIO_PIN_13
#define TaskInt_GPIO_Port GPIOC
#define Right_Pin GPIO_PIN_1
#define Right_GPIO_Port GPIOA
#define Right_EXTI_IRQn EXTI1_IRQn
#define Left_Pin GPIO_PIN_2
#define Left_GPIO_Port GPIOA
#define Left_EXTI_IRQn EXTI2_IRQn
#define Back_Pin GPIO_PIN_3
#define Back_GPIO_Port GPIOA
#define Back_EXTI_IRQn EXTI3_IRQn
#define Select_Pause_Pin GPIO_PIN_4
#define Select_Pause_GPIO_Port GPIOA
#define Select_Pause_EXTI_IRQn EXTI4_IRQn
#define SD_CS_Pin GPIO_PIN_1
#define SD_CS_GPIO_Port GPIOB
#define Change_Pin GPIO_PIN_10
#define Change_GPIO_Port GPIOB
#define Change_EXTI_IRQn EXTI15_10_IRQn
#define TaskIdle_Pin GPIO_PIN_3
#define TaskIdle_GPIO_Port GPIOB
#define TaskPantalla_Pin GPIO_PIN_4
#define TaskPantalla_GPIO_Port GPIOB
#define TaskDatos_Pin GPIO_PIN_5
#define TaskDatos_GPIO_Port GPIOB
#define TaskInterfaz_Pin GPIO_PIN_8
#define TaskInterfaz_GPIO_Port GPIOB

/* USER CODE BEGIN Private defines */
#define SD_SPI_HANDLE hspi2
#define FCLK_SLOW() { MODIFY_REG(SD_SPI_HANDLE.Instance->CR1, SPI_BAUDRATEPRESCALER_256, SPI_BAUDRATEPRESCALER_32); }
/* Set SCLK = slow, approx 280 KBits/s*/

#define FCLK_FAST() { MODIFY_REG(SD_SPI_HANDLE.Instance->CR1, SPI_BAUDRATEPRESCALER_256, SPI_BAUDRATEPRESCALER_2); }
/* Set SCLK = fast, approx 4.5 MBits/s */
/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
