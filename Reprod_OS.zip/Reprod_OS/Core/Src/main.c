/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "cmsis_os.h"
#include "fatfs.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "user_diskio_spi.h"
#include "task.h"
#include "ssd1306.h"
#include "fonts.h"
#include "fft.h"
#include <string.h>
#include "ctype.h"
#include "biquad.h"
//#include "math.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
typedef enum
{
	MENU,
	REPRODUCCION,
	PAUSA
}state_t;

typedef enum
{
	NONE,
	SELECT_EVT,
	BACK_EVT,
	DONE_EVT,
	PAUSE_EVT,
	NOT_PAUSE_EVT
}event_t;
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define AUDIO_BUFFER_SIZE 64
#define SAMPLES_UTILES 32
#define SSD1306_ALTURA 64
#define SSD1306_ANCHO 128
#define FFT_BARRAS 32
#define LUT_SIZE 256

#define POS_MAX 3
#define POS_MIN 1
#define POS_FILTER_MAX 1
#define POS_FILTER_MIN 0

#define MAX_WAV_FILES 50
#define MAX_FILENAME_LEN 13  // 8.3 format + null terminator

#define N 8

#define PEAK_HOLD_DECAY 1
#define PEAK_POTENCIA 65000.0f


/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc1;
DMA_HandleTypeDef hdma_adc1;

I2C_HandleTypeDef hi2c1;

SPI_HandleTypeDef hspi1;

TIM_HandleTypeDef htim1;
TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim3;

/* Definitions for ProcDatos */
osThreadId_t ProcDatosHandle;
const osThreadAttr_t ProcDatos_attributes = {
  .name = "ProcDatos",
  .stack_size = 170 * 4,
  .priority = (osPriority_t) osPriorityHigh,
};
/* Definitions for FFT */
osThreadId_t FFTHandle;
const osThreadAttr_t FFT_attributes = {
  .name = "FFT",
  .stack_size = 210 * 4,
  .priority = (osPriority_t) osPriorityLow,
};
/* Definitions for InterfazUsuario */
osThreadId_t InterfazUsuarioHandle;
const osThreadAttr_t InterfazUsuario_attributes = {
  .name = "InterfazUsuario",
  .stack_size = 275 * 4,
  .priority = (osPriority_t) osPriorityNormal,
};
/* Definitions for FFTCola */
osMessageQueueId_t FFTColaHandle;
const osMessageQueueAttr_t FFTCola_attributes = {
  .name = "FFTCola"
};
/* Definitions for MiSemaforo */
osSemaphoreId_t MiSemaforoHandle;
const osSemaphoreAttr_t MiSemaforo_attributes = {
  .name = "MiSemaforo"
};
/* Definitions for SemaforoFFT */
osSemaphoreId_t SemaforoFFTHandle;
const osSemaphoreAttr_t SemaforoFFT_attributes = {
  .name = "SemaforoFFT"
};
/* USER CODE BEGIN PV */
//extern volatile uint8_t i2c_dma_done;
volatile uint32_t sampleIndex = 0;
UINT bytesRead;

struct cmpx signal_freq[AUDIO_BUFFER_SIZE];

//variables for FatFs
FATFS fs; //Fatfs handle
FIL wavFile; //File handle
FRESULT fres; //Debug result handle
char wav_files[MAX_WAV_FILES][MAX_FILENAME_LEN];
uint8_t wav_count = 0;
DWORD pos_file;


size_t freeHeap;
size_t minEverHeap;
UBaseType_t stackLibreInterfaz;
UBaseType_t stackLibreFFT;
UBaseType_t stackLibreProcDatos;

uint8_t ping[AUDIO_BUFFER_SIZE];
uint8_t pong[AUDIO_BUFFER_SIZE];
uint8_t* puntero_lectura = pong;
uint8_t* puntero_escritura = ping;


uint16_t adc_value;
uint16_t volumen;
uint64_t last_time = 0;
uint8_t peak[FFT_BARRAS+1] = {0};

// flags para la interfaz
volatile uint8_t posicion = 1;
volatile uint8_t flag_select = 0; volatile uint8_t flag_back = 0;
volatile uint8_t flag_pause = 0;
volatile uint8_t flag_change = 0; // 0: en selec_filtro, 1: en selec_gain_filtro
volatile uint8_t pos_filter;

state_t estado = MENU;

float historial[N] = {0};
uint8_t idx = 0;
float factor_escalado_lut;

/* CONTROL DE FILTROS */
uint8_t control_graves = 5; // de 0 a 10, 5 es el valor neutro
uint8_t control_agudos = 5;

/* LUT PARA FFT */
const uint8_t lut[LUT_SIZE] = {
  0,  1,  1,  2,  2,  3,  3,  4,  4,  5,  5,  5,  6,
  6,  7,  7,  8,  8,  8,  9,  9, 10, 10, 10, 11, 11,
 12, 12, 12, 13, 13, 13, 14, 14, 14, 15, 15, 15, 16,
 16, 16, 17, 17, 17, 17, 18, 18, 18, 19, 19, 19, 19,
 20, 20, 20, 20, 21, 21, 21, 21, 22, 22, 22, 22, 23,
 23, 23, 23, 24, 24, 24, 24, 25, 25, 25, 25, 25, 26,
 26, 26, 26, 27, 27, 27, 27, 27, 28, 28, 28, 28, 28,
 29, 29, 29, 29, 29, 30, 30, 30, 30, 30, 30, 31, 31,
 31, 31, 31, 32, 32, 32, 32, 32, 32, 33, 33, 33, 33,
 33, 33, 34, 34, 34, 34, 34, 34, 35, 35, 35, 35, 35,
 35, 35, 36, 36, 36, 36, 36, 36, 37, 37, 37, 37, 37,
 37, 37, 38, 38, 38, 38, 38, 38, 38, 39, 39, 39, 39,
 39, 39, 39, 39, 40, 40, 40, 40, 40, 40, 40, 40, 41,
 41, 41, 41, 41, 41, 41, 41, 42, 42, 42, 42, 42, 42,
 42, 42, 43, 43, 43, 43, 43, 43, 43, 43, 43, 44, 44,
 44, 44, 44, 44, 44, 44, 44, 45, 45, 45, 45, 45, 45,
 45, 45, 45, 46, 46, 46, 46, 46, 46, 46, 46, 46, 47,
 47, 47, 47, 47, 47, 47, 47, 47, 47, 48, 48, 48, 48,
 48, 48, 48, 48, 48, 48, 48, 49, 49, 49, 49, 49, 49,
 49, 49, 49, 49, 50, 50, 50, 50, 50};

/* ECUALIZADORES */

// graves (200Hz, SR=8000Hz) - 11 valores de -15dB a +15dB
/*
const float coef_graves[11][5] = {
    // -15dB
    {0.906250f, -1.681817f, 0.784376f, -1.661454f, 0.710989f},
    // -12dB
    {0.925036f, -1.704714f, 0.790295f, -1.688889f, 0.731156f},
    // -9dB
    {0.943687f, -1.725796f, 0.794891f, -1.714175f, 0.750199f},
    // -6dB
    {0.962317f, -1.745115f, 0.798170f, -1.737466f, 0.768137f},
    // -3dB
    {0.981045f, -1.762715f, 0.800140f, -1.758906f, 0.784994f},
    // +0dB
    {1.000000f, -1.778632f, 0.800803f, -1.778632f, 0.800803f},
    // +3dB
    {1.019321f, -1.792890f, 0.800161f, -1.796773f, 0.815600f},
    // +6dB
    {1.039159f, -1.805503f, 0.798216f, -1.813452f, 0.829426f},
    // +9dB
    {1.059673f, -1.816465f, 0.794966f, -1.828779f, 0.842324f},
    // +12dB
    {1.081039f, -1.825755f, 0.790408f, -1.842862f, 0.854339f},
    // +15dB
    {1.103448f, -1.833328f, 0.784540f, -1.855798f, 0.865518f}
};

// agudos (3000Hz, SR=8000Hz) - 11 valores de -15dB a +15dB

const float coef_agudos[11][5] = {
    // -15dB
    {0.629187f, 0.803530f, 0.299685f, 0.513776f, 0.218627f},
    // -12dB
    {0.691635f, 0.842491f, 0.309380f, 0.606207f, 0.237300f},
    // -9dB
    {0.759296f, 0.877173f, 0.317579f, 0.695605f, 0.258443f},
    // -6dB
    {0.832753f, 0.906379f, 0.324254f, 0.781659f, 0.281727f},
    // -3dB
    {0.912706f, 0.928766f, 0.329456f, 0.864122f, 0.306806f},
    // +0dB
    {1.000000f, 0.942809f, 0.333333f, 0.942809f, 0.333333f},
    // +3dB
    {1.095643f, 0.946769f, 0.336150f, 1.017596f, 0.360966f},
    // +6dB
    {1.200837f, 0.938645f, 0.338308f, 1.088413f, 0.389376f},
    // +9dB
    {1.317009f, 0.916118f, 0.340372f, 1.155244f, 0.418254f},
    // +12dB
    {1.445849f, 0.876483f, 0.343099f, 1.218115f, 0.447316f},
    // +15dB
    {1.589352f, 0.816570f, 0.347476f, 1.277092f, 0.476305f}
};*/
/*
const double coef_agudos[11][5] = {
    {+0.363180784, -0.220162644, +0.086182663, -1.218115286, +0.447316089},  // -12.0 dB
    {+0.467292416, -0.325050758, +0.120768501, -1.155244099, +0.418254259},  // -9.0 dB
    {+0.601844119, -0.470436751, +0.169555581, -1.088413262, +0.389376210},  // -6.0 dB
    {+0.775655812, -0.670261156, +0.237975935, -1.017595677, +0.360966268},  // -3.0 dB
    {+0.880694696, -0.796100982, +0.281743348, -0.980695466, +0.347032529},  // -1.5 dB
    {+1.000000000, -0.942809042, +0.333333333, -0.942809042, +0.333333333},  // 0.0 dB
    {+1.135467267, -1.113547601, +0.394044077, -0.903946606, +0.319910350},  // 1.5 dB
    {+1.289231621, -1.311916525, +0.465369127, -0.864121877, +0.306806100},  // 3.0 dB
    {+1.661559811, -1.808463734, +0.646971862, -0.781658800, +0.281726739},  // 6.0 dB
    {+2.139987651, -2.472208107, +0.895058950, -0.695604607, +0.258443101},  // 9.0 dB
    {+2.753449646, -3.354019102, +1.231662326, -0.606206753, +0.237299623}  // 12.0 dB
};
*/
/*
const double coef_agudos[11][5] = { //andaba piola pero con pitido
    {+0.501187234, +0.199809153, +0.100142502, -0.398671672, +0.199810560},  // -12.0 dB
    {+0.595662144, +0.179260283, +0.111763202, -0.300942884, +0.187628513},  // -9.0 dB
    {+0.707945784, +0.142697493, +0.126555376, -0.201565567, +0.178764221},  // -6.0 dB
    {+0.841395142, +0.085036985, +0.145880359, -0.101066646, +0.173379132},  // -3.0 dB
    {+0.917275935, +0.046385699, +0.157794364, -0.050568970, +0.172024968},  // -1.5 dB
    {+1.000000000, -0.000000000, +0.171572875, -0.000000000, +0.171572875},  // 0.0 dB
    {+1.090184492, -0.055129507, +0.187538953, +0.050568970, +0.172024968},  // 1.5 dB
    {+1.188502227, -0.120117934, +0.206061484, +0.101066646, +0.173379132},  // 3.0 dB
    {+1.412537545, -0.284718931, +0.252511173, +0.201565567, +0.178764221},  // 6.0 dB
    {+1.678804018, -0.505224123, +0.314991502, +0.300942884, +0.187628513},  // 9.0 dB
    {+1.995262315, -0.795454564, +0.398674481, +0.398671672, +0.199810560}  // 12.0 dB
};*/
/*
const double coef_graves[11][5] = {
    {+0.691635281, -0.842491507, +0.309379589, -0.606206753, +0.237299623},  // -12.0 dB
    {+0.759296271, -0.877172537, +0.317578899, -0.695604607, +0.258443101},  // -9.0 dB
    {+0.832752565, -0.906378936, +0.324254038, -0.781658800, +0.281726739},  // -6.0 dB
    {+0.912706091, -0.928765773, +0.329456112, -0.864121877, +0.306806100},  // -3.0 dB
    {+0.955376642, -0.936933541, +0.331546772, -0.903946606, +0.319910350},  // -1.5 dB
    {+1.000000000, -0.942809042, +0.333333333, -0.942809042, +0.333333333},  // 0.0 dB
    {+1.046707608, -0.946167790, +0.334852597, -0.980695466, +0.347032529},  // 1.5 dB
    {+1.095642956, -0.946769047, +0.336149942, -1.017595677, +0.360966268},  // 3.0 dB
    {+1.200836890, -0.938644722, +0.338307861, -1.088413262, +0.389376210},  // 6.0 dB
    {+1.317008969, -0.916117507, +0.340371882, -1.155244099, +0.418254259},  // 9.0 dB
    {+1.445848742, -0.876483272, +0.343099362, -1.218115286, +0.447316089}  // 12.0 dB
};
*/
/*
const double coef_graves[11][5] = { // este funciona piola pero con pitido
    {+0.691635281, -0.842491507, +0.309379589, -0.606206753, +0.237299623},  // -12.0 dB
    {+0.759296271, -0.877172537, +0.317578899, -0.695604607, +0.258443101},  // -9.0 dB
    {+0.832752565, -0.906378936, +0.324254038, -0.781658800, +0.281726739},  // -6.0 dB
    {+0.912706091, -0.928765773, +0.329456112, -0.864121877, +0.306806100},  // -3.0 dB
    {+0.955376642, -0.936933541, +0.331546772, -0.903946606, +0.319910350},  // -1.5 dB
    {+1.000000000, -0.942809042, +0.333333333, -0.942809042, +0.333333333},  // 0.0 dB
    {+1.046707608, -0.946167790, +0.334852597, -0.980695466, +0.347032529},  // 1.5 dB
    {+1.095642956, -0.946769047, +0.336149942, -1.017595677, +0.360966268},  // 3.0 dB
    {+1.200836890, -0.938644722, +0.338307861, -1.088413262, +0.389376210},  // 6.0 dB
    {+1.317008969, -0.916117507, +0.340371882, -1.155244099, +0.418254259},  // 9.0 dB
    {+1.445848742, -0.876483272, +0.343099362, -1.218115286, +0.447316089}  // 12.0 dB
};*/

const double coef_agudos[11][5] = {
    {0.6162191338038486, 0.5809769709461358, 0.20540637793461622, 0.22228169297899042, 0.1803207897056102},  // -12.0 dB
    {0.7123528554144787, 0.6716127128815709, 0.23745095180482625, 0.4186837440948133, 0.20273277600606257},  // -9.0 dB
    {0.8099257747923339, 0.7636053434845704, 0.26997525826411134, 0.6062067533755793, 0.23729962316543646},  // -6.0 dB
    {0.9065274481445909, 0.8546822745530354, 0.302175816048197, 0.7816587996475849, 0.2817267390982383},  // -3.0 dB
    {0.9537751243783359, 0.8992278108999522, 0.31792504145944533, 0.864121876617706, 0.30680610012002774},  // -1.5 dB
    {+1.000000000, 0.9428090415820635, 0.33333333333333337, 0.9428090415820635, 0.33333333333333337},  // 0.0 dB
    {1.048465172177554, 0.9060016921503743, 0.3216755105874688, 0.9428090415820635, 0.33333333333333337},  // 1.5 dB
    {1.103110558920992, 0.8622560753647589, 0.3107757406296461, 0.9428090415820635, 0.33333333333333337},  // 3.0 dB
    {1.2346810425392394, 0.7484719862520879, 0.2929893461240697, 0.9428090415820635,0.33333333333333337},  // 6.0 dB
    {1.4037986826320157, 0.5877476883997389, 0.28459600388364215,0.9428090415820635, 0.33333333333333337},  // 9.0 dB
    {1.6227993341055755, 0.36071858335016566, 0.2926244574596557, 0.9428090415820635, 0.33333333333333337}  // 12.0 dB
};

const double coef_graves[11][5] = {
    {0.6162191338038487, -0.5809769709461358, 0.20540637793461622, -0.22228169297899047, 0.1803207897056102},  // -12.0 dB
    {0.7123528554144788, -0.6716127128815709, 0.23745095180482625, -0.4186837440948133, 0.20273277600606254},  // -9.0 dB
    {0.8099257747923342, -0.7636053434845705, 0.26997525826411134, -0.6062067533755795, 0.23729962316543649},  // -6.0 dB
    {0.906527448144591, -0.8546822745530354, 0.302175816048197, -0.7816587996475849, 0.28172673909823837},  // -3.0 dB
    {0.9537751243783363, -0.8992278108999524, 0.3179250414594454, -0.8641218766177061, 0.3068061001200278},  // -1.5 dB
    {+1.000000000, -0.9428090415820632, 0.3333333333333333, -0.9428090415820632, 0.3333333333333333},  // 0.0 dB
    {1.0484651721775538, -0.9060016921503741, 0.32167551058746874, -0.9428090415820632, 0.3333333333333333},  // 1.5 dB
    {1.1031105589209917, -0.8622560753647589, 0.3107757406296461, -0.9428090415820632, 0.3333333333333333},  // 3.0 dB
    {1.234681042539239, -0.7484719862520879, 0.2929893461240697, -0.9428090415820632, 0.3333333333333333},  // 6.0 dB
    {1.4037986826320155, -0.5877476883997389, 0.2845960038836421, -0.9428090415820632, 0.3333333333333333},  // 9.0 dB
    {1.6227993341055753,-0.36071858335016566, 0.2926244574596557, -0.9428090415820632, 0.3333333333333333}  // 12.0 dB
};
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_SPI1_Init(void);
static void MX_TIM1_Init(void);
static void MX_TIM2_Init(void);
static void MX_I2C1_Init(void);
static void MX_ADC1_Init(void);
static void MX_TIM3_Init(void);
void StartProcDatos(void *argument);
void StartFFT(void *argument);
void StartInterfaz(void *argument);

/* USER CODE BEGIN PFP */
void callback_in(int tag);
void callback_out(int tag);

FRESULT read_wav_files(const char* path, char wav_files[MAX_WAV_FILES][MAX_FILENAME_LEN], uint8_t* count);
int is_wav_file(const char* filename);
void to_lowercase(char* str);
void leer_archivo(const char* filename);

void dibujar_barra(void);
static inline uint16_t get_volume_gain_q8_8(uint16_t adc_raw);
static inline uint8_t apply_volume_q8_8_u8(uint8_t sample, uint16_t gain_q8_8);
float media_movil(float nuevo_valor);
float perceptual_weight(float f);
void CrearFFT(uint8_t* ptr, struct cmpx* signal);
void dibujar_espectro(float* potencia);

void fsm(state_t* state, event_t event);

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
	TickType_t Timing_Now = HAL_GetTick();
	if(Timing_Now - last_time >= 80)
	{
		last_time = Timing_Now;

		if(GPIO_Pin == Right_Pin)
		{
			if(estado == MENU)
				posicion++;
			else if(estado == REPRODUCCION)
			{
				if(!flag_change)
					pos_filter=1;
				else
				{
					switch(pos_filter)
					{
						case 0:
							control_graves++;
							if(control_graves > 10) control_graves = 10;
							break;
						case 1:
							control_agudos++;
							if(control_agudos > 10) control_agudos = 10;
							break;
					}
				}
			}
		}

		else if(GPIO_Pin == Left_Pin)
		{
			if(estado == MENU)
				posicion--;
			else if(estado == REPRODUCCION)
			{
				if(!flag_change)
					pos_filter=0;
				else
				{
					switch(pos_filter)
					{
						case 0:
							if(control_graves > 0) control_graves--; // Para evitar el desborde a 255 en unsigned
							break;
						case 1:
							if(control_agudos > 0) control_agudos--;
							break;
					}
				}
			}
		}

		else if(GPIO_Pin == Back_Pin)
			flag_back = 1;

		else if(GPIO_Pin == Select_Pause_Pin)
		{
			if(estado == MENU) flag_select = 1;
			else if(estado == REPRODUCCION || estado == PAUSA) flag_pause = !flag_pause;
		}

		else if(GPIO_Pin == Change_Pin)
		{
			flag_change = !flag_change;
		}

		if(posicion > POS_MAX) posicion = 1;
		else if(posicion < POS_MIN) posicion = 3;

		if(pos_filter >= POS_FILTER_MAX) pos_filter = POS_FILTER_MAX;
		else if(pos_filter <= POS_FILTER_MIN) pos_filter = POS_FILTER_MIN;
	}
}


/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_SPI1_Init();
  MX_TIM1_Init();
  MX_TIM2_Init();
  MX_FATFS_Init();
  MX_I2C1_Init();
  MX_ADC1_Init();
  MX_TIM3_Init();
  /* USER CODE BEGIN 2 */
  SSD1306_Init();
  HAL_ADC_Start_DMA(&hadc1, (uint32_t*)&volumen, 1);
  HAL_TIM_Base_Start(&htim3);
  HAL_Delay(100);

  // Montar el sistema de archivos
  fres = f_mount(&fs, "", 1);
  if (fres != FR_OK) {
      // Manejar error de montaje
      Error_Handler();
  }

  // Leer archivos .wav del directorio raíz
  fres = read_wav_files("/", wav_files, &wav_count);
  if (fres != FR_OK)
  {
	  Error_Handler();
  }

  // Desmontar el sistema de archivos
  f_mount(NULL, "", 0);

  /* USER CODE END 2 */

  /* Init scheduler */
  osKernelInitialize();

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* Create the semaphores(s) */
  /* creation of MiSemaforo */
  MiSemaforoHandle = osSemaphoreNew(1, 1, &MiSemaforo_attributes);

  /* creation of SemaforoFFT */
  SemaforoFFTHandle = osSemaphoreNew(1, 1, &SemaforoFFT_attributes);

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* Create the queue(s) */
  /* creation of FFTCola */
  FFTColaHandle = osMessageQueueNew (64, sizeof(uint8_t), &FFTCola_attributes);

  /* USER CODE BEGIN RTOS_QUEUES */
  /* add queues, ... */
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /* creation of ProcDatos */
  ProcDatosHandle = osThreadNew(StartProcDatos, NULL, &ProcDatos_attributes);

  /* creation of FFT */
  FFTHandle = osThreadNew(StartFFT, NULL, &FFT_attributes);

  /* creation of InterfazUsuario */
  InterfazUsuarioHandle = osThreadNew(StartInterfaz, NULL, &InterfazUsuario_attributes);

  /* USER CODE BEGIN RTOS_THREADS */
  /* add threads, ... */
  /* USER CODE END RTOS_THREADS */

  /* USER CODE BEGIN RTOS_EVENTS */
  /* add events, ... */
  /* USER CODE END RTOS_EVENTS */

  /* Start scheduler */
  osKernelStart();

  /* We should never get here as control is now taken by the scheduler */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_ADC;
  PeriphClkInit.AdcClockSelection = RCC_ADCPCLK2_DIV6;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief ADC1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC1_Init(void)
{

  /* USER CODE BEGIN ADC1_Init 0 */

  /* USER CODE END ADC1_Init 0 */

  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC1_Init 1 */

  /* USER CODE END ADC1_Init 1 */

  /** Common config
  */
  hadc1.Instance = ADC1;
  hadc1.Init.ScanConvMode = ADC_SCAN_DISABLE;
  hadc1.Init.ContinuousConvMode = DISABLE;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConv = ADC_EXTERNALTRIGCONV_T3_TRGO;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.NbrOfConversion = 1;
  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Regular Channel
  */
  sConfig.Channel = ADC_CHANNEL_8;
  sConfig.Rank = ADC_REGULAR_RANK_1;
  sConfig.SamplingTime = ADC_SAMPLETIME_41CYCLES_5;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC1_Init 2 */

  /* USER CODE END ADC1_Init 2 */

}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.ClockSpeed = 400000;
  hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief SPI1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI1_Init(void)
{

  /* USER CODE BEGIN SPI1_Init 0 */

  /* USER CODE END SPI1_Init 0 */

  /* USER CODE BEGIN SPI1_Init 1 */

  /* USER CODE END SPI1_Init 1 */
  /* SPI1 parameter configuration*/
  hspi1.Instance = SPI1;
  hspi1.Init.Mode = SPI_MODE_MASTER;
  hspi1.Init.Direction = SPI_DIRECTION_2LINES;
  hspi1.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi1.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi1.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi1.Init.NSS = SPI_NSS_SOFT;
  hspi1.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_32;
  hspi1.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi1.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi1.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi1.Init.CRCPolynomial = 10;
  if (HAL_SPI_Init(&hspi1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI1_Init 2 */

  /* USER CODE END SPI1_Init 2 */

}

/**
  * @brief TIM1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM1_Init(void)
{

  /* USER CODE BEGIN TIM1_Init 0 */

  /* USER CODE END TIM1_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM1_Init 1 */

  /* USER CODE END TIM1_Init 1 */
  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 0;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = 9000-1;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim1, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM1_Init 2 */

  /* USER CODE END TIM1_Init 2 */

}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 0;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 256-1;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim2, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */
  HAL_TIM_MspPostInit(&htim2);

}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 1000-1;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 720-1;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_UPDATE;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */

}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMA1_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA1_Channel1_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Channel1_IRQn, 5, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel1_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(TaskInt_GPIO_Port, TaskInt_Pin, GPIO_PIN_SET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, SD_CS_Pin|TestDatos_Pin|TaskIdle_Pin|TaskPantalla_Pin
                          |TaskDatos_Pin|TaskInterfaz_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : TaskInt_Pin */
  GPIO_InitStruct.Pin = TaskInt_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(TaskInt_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : Right_Pin Left_Pin Back_Pin Select_Pause_Pin */
  GPIO_InitStruct.Pin = Right_Pin|Left_Pin|Back_Pin|Select_Pause_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : SD_CS_Pin TestDatos_Pin TaskIdle_Pin TaskPantalla_Pin
                           TaskDatos_Pin TaskInterfaz_Pin */
  GPIO_InitStruct.Pin = SD_CS_Pin|TestDatos_Pin|TaskIdle_Pin|TaskPantalla_Pin
                          |TaskDatos_Pin|TaskInterfaz_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : Change_Pin */
  GPIO_InitStruct.Pin = Change_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(Change_GPIO_Port, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI1_IRQn, 5, 0);
  HAL_NVIC_EnableIRQ(EXTI1_IRQn);

  HAL_NVIC_SetPriority(EXTI2_IRQn, 5, 0);
  HAL_NVIC_EnableIRQ(EXTI2_IRQn);

  HAL_NVIC_SetPriority(EXTI3_IRQn, 5, 0);
  HAL_NVIC_EnableIRQ(EXTI3_IRQn);

  HAL_NVIC_SetPriority(EXTI4_IRQn, 5, 0);
  HAL_NVIC_EnableIRQ(EXTI4_IRQn);

  HAL_NVIC_SetPriority(EXTI15_10_IRQn, 5, 0);
  HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
void callback_in(int tag) { /* Definición en main.c*/
	switch (tag) {
		case TAG_TASK_IDLE: GPIOB->BSRR = GPIO_PIN_3;break;
		case TAG_TASK_PROC_DATOS: GPIOB->BSRR = GPIO_PIN_5;break;
		case TAG_TASK_PANTALLA: GPIOB->BSRR = GPIO_PIN_4;break;
		case TAG_TASK_INTERFAZ: GPIOB->BSRR = GPIO_PIN_8;break;
	}

}

void callback_out(int tag) { /* Definición en main.c*/
	switch (tag) {
		case TAG_TASK_IDLE: GPIOB->BRR = GPIO_PIN_3;break;
		case TAG_TASK_PROC_DATOS: GPIOB->BRR = GPIO_PIN_5;break;
		case TAG_TASK_PANTALLA: GPIOB->BRR = GPIO_PIN_4;break;
		case TAG_TASK_INTERFAZ: GPIOB->BRR = GPIO_PIN_8;break;
	}

}

// Devuelve la ganancia en Q8.8 (0 = 0.0, 256 = 1.0, 512 = 2.0)
static inline uint16_t get_volume_gain_q8_8(uint16_t adc_raw) {
    return (adc_raw * 512) / 4095;
}

static inline uint8_t apply_volume_q8_8_u8(uint8_t sample, uint16_t gain_q8_8) {
    // Convertir a -128 .. 127
    int16_t temp = (int16_t)sample - 128;

    // Aplicar volumen
    temp = (temp * gain_q8_8) >> 8;

    // Saturar
    if (temp > 127) temp = 127;
    if (temp < -128) temp = -128;

    // Convertir de vuelta a 0 .. 255
    return (uint8_t)(temp + 128);
}

void leer_archivo(const char* filename)
{

	  // Montar sistema de archivos
	  fres = f_mount(&fs, "", 1);
	  if (fres != FR_OK) {
	      Error_Handler();
	  }

	  // Abrir archivo
	  fres = f_open(&wavFile, filename, FA_READ);
	  if (fres != FR_OK) {
	      Error_Handler();
	  }

	  // Configurar e iniciar PWM
	  HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_1);
	  //TIM_PWM_Start(TIM2, 1);
	  // Configurar interrupción de actualización a 8kHz
	  HAL_TIM_Base_Start_IT(&htim1);
	  //TIM_Base_Start_IT(TIM1);
}

void CrearFFT(uint8_t* ptr, struct cmpx* signal)
{
	for(uint8_t i = 0; i < AUDIO_BUFFER_SIZE; i++)
	{
		signal[i].real = *(ptr+i);
		signal[i].imag = 0;
	}

	FFT(signal, AUDIO_BUFFER_SIZE);
}

void dibujar_espectro(float *potencia)
{
    // Borra zona del espectro
    SSD1306_DrawFilledRectangle(0, SSD1306_ALTURA - 1 - 50, 127, SSD1306_ALTURA - 1, SSD1306_COLOR_BLACK);

    uint8_t altura, x, y;
    uint8_t mag_dB;

    for(uint8_t i = 1; i < FFT_BARRAS+1; i++)
    {
        float f = i * 8000 / FFT_BARRAS;
    	// indice en LUT
        //uint16_t p = (uint16_t)potencia[i];
        mag_dB = lut[(uint8_t)(potencia[i] * factor_escalado_lut * perceptual_weight(f))];  // escala (0 - 65) a (0 - 255)

        altura = mag_dB;
        if(altura == 0) altura = 1;

        x = i * (SSD1306_ANCHO - 1) / FFT_BARRAS;
        y = SSD1306_ALTURA - 1 - altura;
        SSD1306_DrawLine(x, y, x, SSD1306_ALTURA - 1, SSD1306_COLOR_WHITE);


        // Actualizar y dibujar pico
		if (altura >= peak[i])
			peak[i] = altura; // Nuevo pico
		else if (peak[i] > PEAK_HOLD_DECAY)
			peak[i] -= PEAK_HOLD_DECAY; // Caída lenta
		else
			peak[i] = 0;

		uint8_t peak_y = SSD1306_ALTURA - 1 - peak[i];
		SSD1306_DrawPixel(x, peak_y, SSD1306_COLOR_WHITE); // Píxel de pico

    }

    SSD1306_UpdateScreen();
}

void dibujar_barra()
{
	SSD1306_DrawFilledRectangle(95, 12, SSD1306_ANCHO - 1, 1, SSD1306_COLOR_BLACK); //limpia la barra
	SSD1306_DrawFilledRectangle(95, 1, SSD1306_ANCHO - 1, 1, SSD1306_COLOR_BLACK);
	SSD1306_DrawLine(102, 12, 102 + control_graves + 1, 12, SSD1306_COLOR_WHITE);
	SSD1306_DrawLine(115, 12, 115 + control_agudos + 1, 12, SSD1306_COLOR_WHITE);

	if(pos_filter == 0)
	{
		SSD1306_DrawLine(102, 1, 109, 1, SSD1306_COLOR_WHITE);
		//SSD1306_DrawPixel(105, 1, SSD1306_COLOR_WHITE);
	}
	if(pos_filter == 1)
	{
		SSD1306_DrawLine(115, 1, 122, 1, SSD1306_COLOR_WHITE);
		//SSD1306_DrawPixel(118, 1, SSD1306_COLOR_WHITE);
	}
	//if(estado == PAUSA) SSD1306_DrawFilledRectangle(0, 0, 127, 14, SSD1306_COLOR_BLACK);
}

float media_movil(float nuevo_valor) {
    historial[idx] = nuevo_valor;
    idx = (idx + 1) % N;
    float suma = 0;
    for (uint8_t i = 0; i < N; i++)
        suma += historial[i];

    return suma/(float)N;
}

float perceptual_weight(float f) {
    if (f < 100.0f)       return 0.1f;
    else if (f < 300.0f)  return 0.3f;
    else if (f < 800.0f)  return 0.7f;
    else if (f < 2000.0f) return 1.0f;
    else if (f < 4000.0f) return 0.9f;
    else if (f < 8000.0f) return 0.6f;
    else if (f < 16000.0f)return 0.3f;
    else                  return 0.1f;
}

// Función para convertir string a minúsculas
void to_lowercase(char* str) {
    while (*str) {
        *str = tolower(*str);
        str++;
    }
}

// Función para verificar si un archivo tiene extensión .wav
int is_wav_file(const char* filename) {
    int len = strlen(filename);
    if (len < 4) return 0;

    char temp[13];
    strcpy(temp, filename);
    to_lowercase(temp);

    return (strcmp(&temp[len-4], ".wav") == 0);
}

// Función principal para leer archivos .wav del directorio
FRESULT read_wav_files(const char* path, char wav_files[MAX_WAV_FILES][MAX_FILENAME_LEN], uint8_t* count) {
    DIR dir;
    FILINFO fno;
    FRESULT res;

    *count = 0;

    // Abrir directorio
    res = f_opendir(&dir, path);
    if (res != FR_OK) {
        return res;
    }

    // Leer entradas del directorio
    while (*count < MAX_WAV_FILES) {
        res = f_readdir(&dir, &fno);
        if (res != FR_OK || fno.fname[0] == 0) {
            break; // Error o fin del directorio
        }

        // Verificar si es un archivo (no directorio) y tiene extensión .wav
        if (!(fno.fattrib & AM_DIR) && is_wav_file(fno.fname)) {
            strcpy(wav_files[*count], fno.fname);
            (*count)++;
        }
    }

    // Cerrar directorio
    f_closedir(&dir);

    return res;
}

void fsm(state_t* state, event_t event)
{
	switch(*state)
	{
		case MENU:
			SSD1306_Fill(SSD1306_COLOR_WHITE);
			SSD1306_Stopscroll();
			SSD1306_GotoXY(0, 1);
			SSD1306_Puts(wav_files[0], &Font_7x10, SSD1306_COLOR_BLACK);
			SSD1306_GotoXY(0, 13);
			SSD1306_Puts(wav_files[1], &Font_7x10, SSD1306_COLOR_BLACK);
			SSD1306_GotoXY(0, 25);
			SSD1306_Puts(wav_files[2], &Font_7x10, SSD1306_COLOR_BLACK);

			switch(posicion)
			{
				case 1:
					SSD1306_DrawFilledRectangle(0, 1, 127, 12, SSD1306_COLOR_BLACK);
					SSD1306_GotoXY(0, 1);
					SSD1306_Puts(wav_files[0], &Font_7x10, SSD1306_COLOR_WHITE);
					break;
				case 2:
					SSD1306_DrawFilledRectangle(0, 13, 127, 12, SSD1306_COLOR_BLACK);
					SSD1306_GotoXY(0, 13);
					SSD1306_Puts(wav_files[1], &Font_7x10, SSD1306_COLOR_WHITE);
					break;
				case 3:
					SSD1306_DrawFilledRectangle(0, 25, 127, 12, SSD1306_COLOR_BLACK);
					SSD1306_GotoXY(0, 25);
					SSD1306_Puts(wav_files[2], &Font_7x10, SSD1306_COLOR_WHITE);
					break;
			}

			SSD1306_UpdateScreen();

			if(event == SELECT_EVT)
			{
				*state = REPRODUCCION;
				SSD1306_DrawFilledRectangle(0, 0, 127, 14, SSD1306_COLOR_BLACK);
				SSD1306_GotoXY(115, 2);
				SSD1306_Putc('H', &Font_7x10, SSD1306_COLOR_WHITE);
				SSD1306_GotoXY(102, 2);
				SSD1306_Putc('L', &Font_7x10, SSD1306_COLOR_WHITE);

				//SSD1306_UpdateScreen();
				SSD1306_GotoXY(0, 0);
				SSD1306_Puts(wav_files[posicion-1], &Font_7x10, SSD1306_COLOR_WHITE);
				leer_archivo(wav_files[posicion-1]);

				SSD1306_UpdateScreen();
			}
			break;

		case REPRODUCCION:
			osSemaphoreRelease(SemaforoFFTHandle); // Libera el semaforo

			if(event == PAUSE_EVT)
			{
				*state = PAUSA;
				HAL_TIM_PWM_Stop(&htim2, TIM_CHANNEL_1);
				HAL_TIM_Base_Stop_IT(&htim1);
				//f_close(&wavFile);
				SSD1306_DrawFilledRectangle(0, 0, 127, 14, SSD1306_COLOR_BLACK);

				SSD1306_DrawLine(115, 2, 115, 12, SSD1306_COLOR_WHITE);     // lado izquierdo (vertical)
				SSD1306_DrawLine(115, 2, 115, 6, SSD1306_COLOR_WHITE);      // lado superior inclinado
				SSD1306_DrawLine(115, 12, 115, 6, SSD1306_COLOR_WHITE);   // lado inferior inclinado
				SSD1306_UpdateScreen();
				SSD1306_GotoXY(0, 0);
				SSD1306_Puts("PAUSED", &Font_7x10, SSD1306_COLOR_WHITE);
				SSD1306_UpdateScreen();

			}

			else if(event == DONE_EVT || event == BACK_EVT)
			{
				*state = MENU;
				f_close(&wavFile);
				HAL_TIM_PWM_Stop(&htim2, TIM_CHANNEL_1);
				HAL_TIM_Base_Stop_IT(&htim1);
			}
			break;

		case PAUSA:
			if(event == NOT_PAUSE_EVT)
			{
				*state = REPRODUCCION;
				HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_1);
				HAL_TIM_Base_Start_IT(&htim1);
				SSD1306_DrawFilledRectangle(0, 0, 127, 14, SSD1306_COLOR_BLACK);
				SSD1306_UpdateScreen();
				SSD1306_GotoXY(0, 0);
				SSD1306_Puts(wav_files[posicion-1], &Font_7x10, SSD1306_COLOR_WHITE);

				//SSD1306_DrawFilledRectangle(0, 0, 127, 13, SSD1306_COLOR_BLACK);
				SSD1306_GotoXY(115, 2);
				SSD1306_Putc('H', &Font_7x10, SSD1306_COLOR_WHITE);
				SSD1306_GotoXY(102, 2);
				SSD1306_Putc('L', &Font_7x10, SSD1306_COLOR_WHITE);
				SSD1306_UpdateScreen();
				//leer_archivo(wav_files[posicion-1]);
				f_lseek(&wavFile, pos_file);
			}

			else if(event == BACK_EVT)
			{
				*state = MENU;
				f_close(&wavFile);
				HAL_TIM_PWM_Stop(&htim2, TIM_CHANNEL_1);
				HAL_TIM_Base_Stop_IT(&htim1);
			}
			break;
	}
}
/* USER CODE END 4 */

/* USER CODE BEGIN Header_StartProcDatos */
/**
  * @brief  Function implementing the ProcDatos thread.
  * @param  argument: Not used
  * @retval None
  */
/* USER CODE END Header_StartProcDatos */
void StartProcDatos(void *argument)
{
  /* USER CODE BEGIN 5 */
  /* Infinite loop */
	vTaskSetApplicationTaskTag( NULL, (void*) TAG_TASK_PROC_DATOS);
	uint8_t buffer_auxiliar[AUDIO_BUFFER_SIZE] = {0};
	float muestra_procesada[AUDIO_BUFFER_SIZE] = {0};
	uint16_t gain_q8_8;
  for(;;)
  {
	  TestDatos_GPIO_Port->BSRR = TestDatos_Pin;
	  stackLibreProcDatos = uxTaskGetStackHighWaterMark(NULL);
	  if(estado == REPRODUCCION)
	  {

		fres = f_read(&wavFile, buffer_auxiliar, AUDIO_BUFFER_SIZE, &bytesRead);
		if (fres != FR_OK) {
			Error_Handler();
		}
		pos_file = f_tell(&wavFile); // guardo la posicion en la que estoy leyendo el archivo


		biquad filter_graves =
		{
			.a0 = coef_graves[control_graves][0],
			.a1 = coef_graves[control_graves][1],
			.a2 = coef_graves[control_graves][2],
			.a3 = coef_graves[control_graves][3],
			.a4 = coef_graves[control_graves][4],
			.x1 = buffer_auxiliar[0],
			.x2 = 127,
			.y1 = 127,
			.y2 = 127,
		};


		biquad filter_agudos =
		{
			.a0 = coef_agudos[control_agudos][0],
			.a1 = coef_agudos[control_agudos][1],
			.a2 = coef_agudos[control_agudos][2],
			.a3 = coef_agudos[control_agudos][3],
			.a4 = coef_agudos[control_agudos][4],
			.x1 = buffer_auxiliar[0],
			.x2 = 127,
			.y1 = 127,
			.y2 = 127,
		};

		gain_q8_8 = get_volume_gain_q8_8(volumen);

		for(uint8_t index = 0; index < AUDIO_BUFFER_SIZE; index++) // procesamiento en cascada
		{
		    // Aplico volumen en punto fijo
		    buffer_auxiliar[index] = apply_volume_q8_8_u8(buffer_auxiliar[index], gain_q8_8);

		    // Paso por filtro de graves
		    muestra_procesada[index] = BiQuad(buffer_auxiliar[index], &filter_graves);

		    // Paso por filtro de agudos
		    puntero_escritura[index] = (uint8_t)BiQuad(muestra_procesada[index], &filter_agudos);
		}
	  }
	  TestDatos_GPIO_Port->BRR = TestDatos_Pin;
	  osSemaphoreAcquire(MiSemaforoHandle, osWaitForever); // La tarea se bloquea
  }
  /* USER CODE END 5 */
}

/* USER CODE BEGIN Header_StartFFT */
/**
* @brief Function implementing the FFT thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_StartFFT */
void StartFFT(void *argument)
{
  /* USER CODE BEGIN StartFFT */
  /* Infinite loop */
	vTaskSetApplicationTaskTag( NULL, (void*) TAG_TASK_PANTALLA);
	TickType_t last_time = xTaskGetTickCount();
	float mod_cuadrado[FFT_BARRAS];
	uint8_t muestras[AUDIO_BUFFER_SIZE];
	factor_escalado_lut = LUT_SIZE / PEAK_POTENCIA;
	//float mod_suavizado[FFT_BARRAS] = {0};
	//float alpha = 0.3f;
  for(;;)
  {
	    stackLibreFFT = uxTaskGetStackHighWaterMark(NULL);
		for(uint8_t i = 0; i < AUDIO_BUFFER_SIZE; i++)
			osMessageQueueGet(FFTColaHandle, &muestras[i], 0, osWaitForever);

		CrearFFT(muestras, signal_freq);

		mod_cuadrado[0] = (signal_freq[0].real * signal_freq[0].real + signal_freq[0].imag * signal_freq[0].imag);
		mod_cuadrado[0] = (mod_cuadrado[0] > 0.0f) ? mod_cuadrado[0] : 1.0f;
		mod_cuadrado[0] = (mod_cuadrado[0] > 65000.0f) ? 65000.0f : mod_cuadrado[0];
		//mod_suavizado[0] = alpha * media_movil(mod_cuadrado[0]);
		//mod_suavizado[0] = alpha * mod_cuadrado[0];
		//mod_cuadrado[0] = media_movil(mod_cuadrado[0]);

		for(uint8_t i = 1; i < FFT_BARRAS; i++)
		{
			mod_cuadrado[i] = (signal_freq[i].real * signal_freq[i].real + signal_freq[i].imag * signal_freq[i].imag);
			mod_cuadrado[i] = (mod_cuadrado[i] > 0.0f) ? mod_cuadrado[i] : 1.0f;
			mod_cuadrado[i] = (mod_cuadrado[i] > 65000.0f) ? 65000.0f : mod_cuadrado[i];
			//mod_cuadrado[i] = media_movil(mod_cuadrado[i]);
			//mod_suavizado[i] = alpha * mod_cuadrado[i] + (1.0f - alpha) * mod_suavizado[i-1];
		}


		// La tarea se bloquea hasta que lo libere el estado de REPRODUCCION
		osSemaphoreAcquire(SemaforoFFTHandle, osWaitForever);

		//dibujar_espectro(media_movil[mod_cuadrado]);
		//dibujar_espectro(mod_suavizado);
		dibujar_barra();
		if(estado == PAUSA) // Para borrar la interfaz de los filtros al estar en pausa
			SSD1306_DrawFilledRectangle(95, 0, SSD1306_ANCHO - 1 - 85, 12, SSD1306_COLOR_BLACK);
		dibujar_espectro(mod_cuadrado);

		vTaskDelayUntil(&last_time, pdMS_TO_TICKS(100));


  }

  /* USER CODE END StartFFT */
}

/* USER CODE BEGIN Header_StartInterfaz */
/**
* @brief Function implementing the InterfazUsuario thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_StartInterfaz */
void StartInterfaz(void *argument)
{
  /* USER CODE BEGIN StartInterfaz */
  /* Infinite loop */
  vTaskSetApplicationTaskTag( NULL, (void*) TAG_TASK_INTERFAZ);
  TickType_t last_time = xTaskGetTickCount();
  SSD1306_GotoXY(40, 31);
  SSD1306_Puts("Welcome!", &Font_7x10, SSD1306_COLOR_WHITE);
  SSD1306_ScrollRight(0, 127);
  SSD1306_UpdateScreen();
  HAL_Delay(1000);
  fsm(&estado, NONE); // Va al menu

  for(;;)
  {
	 freeHeap = xPortGetFreeHeapSize(); // RAM libre en el heap actualmente (en bytes)
	 minEverHeap = xPortGetMinimumEverFreeHeapSize(); // el heap minimo en toda la ejecucion (en bytes)
	 stackLibreInterfaz = uxTaskGetStackHighWaterMark(NULL); // palabras del stack libres
	 // en el peor momento desde el arranque (tecnicamente no es el peor posible)

	if(flag_select)
	{
		flag_select = 0;
		fsm(&estado, SELECT_EVT);
	}

	else if(flag_pause)
	{
		fsm(&estado, PAUSE_EVT);
		if(flag_back) fsm(&estado, BACK_EVT);
	}
	else if(estado == PAUSA && !flag_pause)
			fsm(&estado, NOT_PAUSE_EVT);

	else if(flag_back)
	{
		flag_back = 0;
		fsm(&estado, BACK_EVT);
	}

	else
	{
		fsm(&estado, NONE); // me quedo en el menu
	}

	if(f_eof(&wavFile)) // si termina el archivo
	{
		fsm(&estado, DONE_EVT);
		f_lseek(&wavFile, 44); // Evita el header de .wav
	}

	vTaskDelayUntil(&last_time, pdMS_TO_TICKS(20));
  }
  /* USER CODE END StartInterfaz */
}

/**
  * @brief  Period elapsed callback in non blocking mode
  * @note   This function is called  when TIM4 interrupt took place, inside
  * HAL_TIM_IRQHandler(). It makes a direct call to HAL_IncTick() to increment
  * a global variable "uwTick" used as application time base.
  * @param  htim : TIM handle
  * @retval None
  */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  /* USER CODE BEGIN Callback 0 */
	 if (htim->Instance == TIM1)
	    {
	        TaskInt_GPIO_Port->BRR = TaskInt_Pin;
	        /*ADC1->CR2 |= ADC_CR2_SWSTART;      // Iniciar conversión
			while (!(ADC1->SR & ADC_SR_EOC));  // Esperar que termine
			adc_value = ADC1->DR;          	   // Leer el valor
			ADC1->SR &= ~ADC_SR_EOC;           // Limpiar el flag EOC (opcional)
			*/
	        //if(flag_change)
	        //{
	        //pos_filter = adc_value * 3 / 4095;
	        //}
	        //if(pos_filter < 1) pos_filter = 1;

			// Enviar muestra al PWM
			TIM2->CCR1 = (uint16_t)(puntero_lectura[sampleIndex]);
	        //TIM2->CCR1 = 127;
			osMessageQueuePut(FFTColaHandle, &puntero_lectura[sampleIndex], 0, 0);

	        //TIM2->CCR1 = (uint16_t)(lectura_filtrada[sampleIndex]);
	        //osMessageQueuePut(FFTColaHandle, &lectura_filtrada[sampleIndex], 0, 0);

	        sampleIndex++;
			// Recargar buffer
			if (sampleIndex >= AUDIO_BUFFER_SIZE)
			{
				sampleIndex = 0;

				/*
				if(pos_filter == 1)
					control_graves = adc_value * 10 / 4095;
				else if(pos_filter == 2)
					control_medios = adc_value * 10 / 4095;
				else if(pos_filter == 3)
					control_agudos = adc_value * 10 / 4095;
				*/
				osSemaphoreRelease(MiSemaforoHandle); // Libera el semaforo

				if(puntero_escritura == ping)
				{
					puntero_escritura = pong;
					puntero_lectura = ping;
					//lectura_filtrada = ping;
				}
				else
				{
					puntero_escritura = ping;
					puntero_lectura = pong;
					//lectura_filtrada = pong;
				}
			}
			//HAL_GPIO_WritePin(TaskInt_GPIO_Port, TaskInt_Pin, GPIO_PIN_SET);
			TaskInt_GPIO_Port->BSRR = TaskInt_Pin;
	     }
  /* USER CODE END Callback 0 */
  if (htim->Instance == TIM4)
  {
    HAL_IncTick();
  }
  /* USER CODE BEGIN Callback 1 */

  /* USER CODE END Callback 1 */
}

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
